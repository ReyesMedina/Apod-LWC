import { LightningElement} from 'lwc';
import getCallout from '@salesforce/apex/ApodController.getCallout';
import nlogo from '@salesforce/resourceUrl/nasalogo';
import textToSpeechStringEncode from '@salesforce/apex/ApodController.textToSpeechStringEncode';
import {ShowToastEvent} from 'lightning/platformShowToastEvent';

export default class ApodLWC extends LightningElement {

        //Variables for get api's data
        pictureUrl;
        factexplanation;
        factdate;
        dateValue="2020-04-06";
        titlePicture;
        nasaimg=nlogo;
        urlaud;

        //Boolean Variables for Load Content
        contentaudio=false;
        download=false;
        getExplanation=false;

        
        




        handleDate(event){
            this.dateValue = event.target.value;
        }


        //Click Button event Api Apod
        handleClick(event){
            this.contentaudio=false;
          
            if(this.getExplanation===true){
                this.getExplanation=false;
            }
            // calling Apex method from LWC
            getCallout({
                Setdate : this.dateValue
            }).then(result=>{
                
                const obj = JSON.parse(result);
                if(obj.code===400){
                    const toastEvent = new ShowToastEvent({
                        title : 'Error Get Response',
                        message : obj.msg,
                        variant : 'error'
                       });
                       this.dispatchEvent(toastEvent);
                    this.getExplanation=false;
                    //alert(obj.msg);
                }
              
               this.pictureUrl=obj.hdurl;
               this.factexplanation=obj.explanation;
               this.factdate=obj.date;
               this.titlePicture=obj.title;
               this.getExplanation=true;
             
            });

           
  
        }


         //Click Button event Api TextToSpeech
        readAloud(event){
           
            const b64toBlob = (b64Data, contentType='', sliceSize=512) => {
                const byteCharacters = atob(b64Data);
                const byteArrays = [];
                for (let offset = 0; offset < byteCharacters.length; offset += sliceSize) {
                    const slice = byteCharacters.slice(offset, offset + sliceSize);
                    const byteNumbers = new Array(slice.length);
                    for (let i = 0; i < slice.length; i++) {
                        byteNumbers[i] = slice.charCodeAt(i);
                    }
                    const byteArray = new Uint8Array(byteNumbers);
                    byteArrays.push(byteArray);
                }
                const blob = new Blob(byteArrays, {type: contentType});
                return blob;
            }
            // calling Apex method from LWC
             textToSpeechStringEncode({
                text : this.factexplanation,
                titleAudio : this.titlePicture
            }).then( (base64Data) => {
                const contentType = 'audio/mpeg'; // content type for audio/mp3
                const blob = b64toBlob(base64Data, contentType);
                
             
                const audioUrl = URL.createObjectURL(blob);
              
                this.urlaud = audioUrl;
               this.contentaudio=true;
               const toastEvent = new ShowToastEvent({
                title : 'Sucess Get Audio',
                message : 'Audio Explanation is ready! Go to Files',
                variant : 'success'
               });
               this.dispatchEvent(toastEvent);
            
       
            }).catch((error) => {
                console.error(error);
            })

          
        }
      
        

       

}